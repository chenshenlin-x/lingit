truncate table LIVEBOS.LBROLECATEGORY;
delete  LIVEBOS.OS_CURRENTSTEP;
truncate table LIVEBOS.OS_CURRENTSTEP_PREV;
delete  LIVEBOS.OS_HISTORYSTEP;
truncate table LIVEBOS.OS_HISTORYSTEP_PREV;
truncate table LIVEBOS.OS_HISTORYWORKFLOWDEFS;
delete  LIVEBOS.OS_WFENTRY;
truncate table LIVEBOS.TOPERLOG;
--delete from  LIVEBOS.TUSER where userid!='admin';
truncate table LIVEBOS.LBWFCURRENTOWNER;
truncate table LIVEBOS.LBWORKACTIONSTATISTIC;
--truncate table LIVEBOS.LBNOTIFICATION;
truncate table LIVEBOS.lbdeveloplog;
--delete livebos.lborganization where id!=1;
truncate table LIVEBOS.TYHCZRZ;


