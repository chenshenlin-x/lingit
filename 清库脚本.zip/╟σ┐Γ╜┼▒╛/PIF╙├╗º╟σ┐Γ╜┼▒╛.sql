truncate table  lcPIF_HKSPLC;
truncate table  lcPIF_CPTGZHKL;
truncate table  lcPIF_JH_CPZYZJTCGG;
truncate table  lcPIF_JH_CPKFQGG;
truncate table  lcPIF_JH_CPZYZJGG;
truncate table  lcPIF_JH_CPFHGG;
truncate table  lcPIF_JH_CPQP;
truncate table  lcPIF_JH_CPBA;
truncate table  lcPIF_CPTGZHKL;
truncate table  lcPIF_DY_CPHTSP;
truncate table  lcPIF_DY_CPCLTZSBD;
truncate table  lcPIF_DY_CPZCYZQRS;
truncate table  lcPIF_YXJZHKL;
truncate table  lcPIF_YXJZHKL_ZZD;
truncate table  lcPIF_DY_CPLXBD;
truncate table  lcPIF_RHBASQ;
truncate table  lcPIF_CPZJZHKL;
truncate table  lcPIF_ZHXHLC;
truncate table  lcPIF_XXPLLC;
truncate table  lcPIF_TZJLBBLC;
truncate table  lcPIF_XXHTSP;
truncate table  lcPIF_CPFXDJPJSQ;
truncate table  lcPIF_JH_CPLXBD;
truncate table  lcPIF_JH_HTSPBD;
truncate table  lcPIF_JH_CPHTBGSQBD;
truncate table  lcPIF_JH_CPMJTGSQ;
truncate table  lcPIF_JH_CPMJCSSZ;
truncate table  lcPIF_JH_CPCLGG;
truncate table  lcPIF_DY_CPBABD;
truncate table  lcPIF_DY_CPQPLC;
truncate table  lcPIF_XGSGSP;
truncate table  lcPIF_DY_WTZCZJTZS;
truncate table  lcPIF_DY_WTZCTQTZS;

truncate table Lcpif_Cpzqzhkl;

truncate table Lcpif_Jh_Cpdxxy;

truncate table Lcpif_Jh_Cpdxxy_Fymx;

truncate table Lcpif_Jh_Cpdxxy_Fymx_Fdfl;

truncate table LCPIF_DY_WTRZJHBSQ;

TRUNCATE TABLE LCPIF_XGRCSP;

TRUNCATE TABLE LCPIF_GZYZLC;

TRUNCATE TABLE LCPIF_BMZYZLC;

delete lcPIF_GMCPDJ;
delete lcPIF_GMCPYSBG;

--��������
delete lcPIF_DXCPHT;
delete lcPIF_DXCPHTBG;
delete lcPIF_DXCPLX;
delete lcPIF_DXCPYSBG;
delete lcPIF_JHCPHT;
delete lcPIF_JHCPHTBG;
delete lcPIF_JHCPLX;
delete lcPIF_JHCPYSBG;
--�л�Э����
delete lcPIF_CPBA;
delete lcPIF_CPBABG;

--��������
DELETE FROM TPIF_CPYHZHXX;
DELETE FROM TPIF_CPZQZHGL;
DELETE FROM TPIF_CPZJZH;
DELETE FROM TPIF_XWGL;
DELETE FROM TPIF_LXRXX;
DELETE FROM TPIF_JGGLFXX;
--DELETE FROM TPIF_CPWDK; --��Ʒ�ĵ���
DELETE FROM TPIF_DYTZZXX;
DELETE FROM TPIF_CPLCWD; --�����ĵ���
DELETE FROM TPIF_LCZFJL;
DELETE FROM TPIF_LCZX;
DELETE FROM TPIF_ZJHBLS;
DELETE FROM TPIF_CPFLFA; --���ʷ���
DELETE FROM TPIF_JYCS;
DELETE FROM TPIF_XGSGSP;
DELETE FROM TPIF_ZYZJCYSQ;
DELETE FROM TPIF_ZQJYZL;
